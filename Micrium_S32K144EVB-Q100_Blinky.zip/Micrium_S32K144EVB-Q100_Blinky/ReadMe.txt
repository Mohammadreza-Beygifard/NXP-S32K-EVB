BLINKY EXAMPLE FOR THE NXP S32K144EVB-Q100

This example project demonstrates how to create a kernel task which blinks the RGB LED.

MICRIUM PRODUCT VERSIONS
- uC/OS-III v3.06.02
- uC/OS-II  v2.92.14
- uC/CPU    v1.31.02
- uC/LIB    v1.38.02

IDE/COMPILER VERSIONS
- S32 Design Studio for ARM 2018.R1

HARDWARE SETUP
- Connect a micro USB cable to a PC.
- Connect the other end of the micro USB cable to the mini-B port J7 (OpenSDA).
- Ensure that the jumpers are in their default configuration.

PROJECT LOCATION
- NXP/S32K144EVB-Q100/Blinky/<OS3||OS2>/S32DS/.project

USAGE INSTRUCTIONS
- Import the project into your S32DS workspace (File->Import->Existing Projects into Workspace).
- Right-click "S32DS_Debug.launch" in the Project Explorer inside the "Project_Settings/Debugger" folder and select "Debug as->S32DS_Debug".
- After the project builds, the debugger will flash it to the target.
- When the target has been flashed, press F8 to run the example. You should see the RGB LED cycles through colors every 500 ms.


Please feel free to post questions or comments related to this example project at Micrium's forum page:

https://www.micrium.com/forums/topic/nxp-s32k144evb-q100-blinky/
/********************************************************************************************************
*
*
*										Filename:  bsp__switch.c
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/

#include <lib_def.h>
#include <cpu.h>
#include <bsp_int.h>
#include <os.h>
#include <bsp_flextimerled.h>	
#include "bsp_switch.h"
#include "S32K144.h"

/*************************************** Function Prototypes ********************************************/

static void SW_IRQHandler(void);

/************************************ BSP_Switch_Init ***************************************************/

void BSP_Switch_Init(void)
{
	PCC->PCCn[PCC_PORTC_INDEX] = PCC_PCCn_CGC_MASK; 	// Enable clock to PORT C
	PTC->PDDR &= ~DEF_BIT_12;							// Set PC12 (SW2) as an input pin
	PORTC->PCR[12] = 0x100u; 							// Configure PTC12 muxing as a GPIO function
	PORTC->PCR[13] = 0x100u;
	/* Interrupt configuration */
	PORTC->PCR[12] |= 0x00090000u;
	PORTC->PCR[13] |= 0x00090000u;// Configure PTC12 for rising edge interrupt
	BSP_IntVectSet(PORTC_IRQn, 0, 0, SW_IRQHandler); 	// Register Interrupt Handler
	BSP_IntEnable(PORTC_IRQn); 						// Enable the interrupt for PORTC
}

/********************************************* SW_IRQHandler *****************************************/

static void SW_IRQHandler(void)
{
	uint32_t ifsr2;
	uint32_t ifsr3;

	OSIntEnter();
	/* Check ISF (Interrupt Status Flag) */
	ifsr2 = (PORTC->PCR[12]) & 0x01000000;
	ifsr3 = (PORTC->PCR[13]) & 0x01000000;
	if (ifsr2)
	{
		BSP_FTM0_ToggleLEDColor2();
		PORTC->PCR[12] |= 0x01000000;					// Clear ISF by writing 1 to it
	}
	if (ifsr3)
	{
		BSP_FTM0_ToggleLEDColor3();
		PORTC->PCR[13] |= 0x01000000;					// Clear ISF by writing 1 to it
	}
	OSIntExit();
}

/********************************************************************************************************
*
*
*										Filename:  bsp__flextimerled.c
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/

#include <lib_def.h>
#include <bsp_int.h>
#include <os.h>
#include "bsp_flextimerled.h"
#include "S32K144.h"

/************************************ Project Specific Variables *****************************************/
volatile LEDCOLOR_VAR LED_COLOR = RED;

/*********************************** BSP_FTM0_PWM_Init ************************************/

void BSP_FTM0_PWM_Init(void)
{
	
	PCC->PCCn[PCC_PORTD_INDEX] = PCC_PCCn_CGC_MASK; // Enable clk on PORT D 

	
	PCC->PCCn[PCC_FTM0_INDEX] = PCC_PCCn_CGC_MASK | PCC_PCCn_PCS(6); 



	PORTD->PCR[0]  = PORT_PCR_MUX(2); 		// PTD15 (BLUE) -> FTM0_CH2 function
	PORTD->PCR[15] = PORT_PCR_MUX(2); 		// PTD15 (RED) -> FTM0_CH0 function
	PORTD->PCR[16] = PORT_PCR_MUX(2); 		// PTD16 (GREEN) -> FTM0_CH1 function
	

	FTM0->MODE = FTM_MODE_FTMEN_MASK; 		// Enable registers updating from write buffers
	// Configure the registers to have 10 KHz PWM frequency when the system clk is at 80 MHz
	FTM0->MOD = FTM_MOD_MOD(8000 - 1); 		// prescaler = 1
	FTM0->CNTIN = FTM_CNTIN_INIT(0); 		// initialization CNTIN to 0

	// Enable high pulse of PWM for CH0(RED), CH1(GREEN), CH2(Blue) 
	FTM0->CONTROLS[0].CnSC = FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK;
	FTM0->CONTROLS[0].CnV = FTM_CnV_VAL(4000); 	// arbitrary duty cycle
	
	FTM0->CONTROLS[1].CnSC = FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK;
	FTM0->CONTROLS[1].CnV = FTM_CnV_VAL(4000); 	// arbitrary duty cycle
	
	FTM0->CONTROLS[2].CnSC = FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK;
	FTM0->CONTROLS[2].CnV = FTM_CnV_VAL(4000); 	// arbitrary duty cycle

	FTM0->CNT = 0; 							// Reset FTM counter
	// selection of the Clk and PWM generation on CH0 is enabled
	FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN0_MASK;
}

/******************************* BSP_FTM0_ChangeDutyCycle *********************************/

void BSP_FTM0_ChangeDutyCycle(CPU_INT16U updatedDutyCycle)
{
	CPU_INT32U SCRegtemp;	

	SCRegtemp = FTM0->SC;	// Store the state of SCReg of FTM0 in a temporary var
	FTM0->SC = 0;			// Disable FTM0

	/// Update all the duty cycles of all the PWM signals
	FTM0->CONTROLS[0].CnV = FTM_CnV_VAL(updatedDutyCycle);
	FTM0->CONTROLS[1].CnV = FTM_CnV_VAL(updatedDutyCycle);
	FTM0->CONTROLS[2].CnV = FTM_CnV_VAL(updatedDutyCycle);

	FTM0->SC = SCRegtemp;	// the saved SCReg is backed up
}

/******************************* BSP_FTM0_ToggleLEDColor **********************************/

void BSP_FTM0_ToggleLEDColor2(void)
{
	switch (LED_COLOR) {
	case RED:	// set GREEN
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN1_MASK;
		LED_COLOR = GREEN;
		break;
	case GREEN:	// set BLUE
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN2_MASK;
		LED_COLOR = BLUE;
		break;
	case BLUE:	// set RED
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN0_MASK;
		LED_COLOR = RED;
		break;
	default:
		// We never get here
		break;
	}
}
void BSP_FTM0_ToggleLEDColor3(void)
{
	switch (LED_COLOR) {
	case RED:	// set GREEN
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN2_MASK;
		LED_COLOR = BLUE;
		break;
	case BLUE:	// set BLUE
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN1_MASK;
		LED_COLOR = GREEN;
		break;
	case GREEN:	// set RED
		FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PWMEN0_MASK;
		LED_COLOR = RED;
		break;
	default:
		// We never get here
		break;
	}
}

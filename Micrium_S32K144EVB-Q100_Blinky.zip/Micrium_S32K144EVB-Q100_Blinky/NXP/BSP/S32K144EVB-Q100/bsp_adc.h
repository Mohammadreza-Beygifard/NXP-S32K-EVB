/********************************************************************************************************
*
*
*										Filename:  bsp__adc.h
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/

#ifndef BSP_ADC_PRESENT
#define BSP_ADC_PRESENT

#ifdef __cplusplus
extern "C" {
#endif

	/******************************************* Function Prototypes *********************************************/
	void BSP_ADC0_Init(void);
	void BSP_ADC0_convertAdcChan_interrupt(CPU_INT16U adcChan);

#ifdef __cplusplus
}
#endif

#endif

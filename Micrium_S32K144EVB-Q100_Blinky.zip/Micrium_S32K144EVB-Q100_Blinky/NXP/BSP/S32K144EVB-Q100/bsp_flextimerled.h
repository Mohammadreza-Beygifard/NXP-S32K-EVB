/********************************************************************************************************
*
*
*										Filename:  bsp_flextimerled.h
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/
#ifndef BSP_TIMER_PRESENT
#define BSP_TIMER_PRESENT

#ifdef __cplusplus
extern "C" {
#endif

	// Definition of TypeColor
	typedef enum bsp_color {
		RED,
		GREEN,
		BLUE
	} LEDCOLOR_VAR;

	// Prototypes of our functions
	void BSP_FTM0_PWM_Init(void);
	void BSP_FTM0_ChangeDutyCycle(CPU_INT16U updatedDutyCycle);
	void BSP_FTM0_ToggleLEDColor2(void);
	void BSP_FTM0_ToggleLEDColor3(void);
#ifdef __cplusplus
}
#endif

#endif

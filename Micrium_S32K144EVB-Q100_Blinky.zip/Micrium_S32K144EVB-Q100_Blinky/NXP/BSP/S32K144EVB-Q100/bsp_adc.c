/********************************************************************************************************
*
*
*										Filename:  bsp__adc.c
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/

#include <lib_def.h>		// For macros definitions
#include <bsp_int.h>		// For interrupts
#include <os.h>				// For OS_ERR type
#include "bsp_adc.h"
#include "S32K144.h"

/******************************************* Variable Declarations ***********************************************/

volatile CPU_INT16U ADC0_conv; 	// Global variable for ADC conversion result
OS_SEM ADC0sem;

/*********************************************** Function Prototypes *****************************************************/

static void ADC0_IRQHandler(void);

/************************************************* BSP_ADC0_Init *****************************************************/

void BSP_ADC0_Init(void)
{
	// Selecting the Peripheral Clock  
	PCC->PCCn[PCC_ADC0_INDEX] &= ~PCC_PCCn_CGC_MASK;	// Disable clock to change PCS
	PCC->PCCn[PCC_ADC0_INDEX] |= PCC_PCCn_PCS(1); 		// PCS=1: Select SOSCDIV2
	PCC->PCCn[PCC_ADC0_INDEX] |= PCC_PCCn_CGC_MASK; 	// Enable bus Clk in ADC

	ADC0->SC1[0] = 0x003F | 0x0040; 		// ADCH=0x3F: Module disabled for conversions
											// AIEN=1: Interrupts are disabled

	ADC0->CFG1 = 0x000000004; 				// ADICLK=0: Input clk=ALTCLK1=SOSCDIV2
											// ADIV=0: Prescaler=1
											// MODE=1: 12-bit conversion
	ADC0->CFG2 = 0x00000000C; 				// SMPLTS=12: sample time is 13 ADC clks

	ADC0->SC2 = 0x00000000; 				// ADTRG=0: SW trigger
											// ACFE,ACFGT,ACREN=0: Compare func disabled
											// DMAEN=0: DMA disabled
											// REFSEL=0: Voltage reference pins=VREFH,VREEFL

	ADC0->SC3 = 0x00000000;					// CAL=0: Do not start calibration sequence
											// ADCO=0: One conversion performed
											// AVGE,AVGS=0: HW average function disabled
	/* Enable interrupt for ADC0 */
	BSP_IntVectSet(ADC0_IRQn, 0, 0, ADC0_IRQHandler);
	BSP_IntEnable(ADC0_IRQn);
}

/******************************** BSP_ADC0_convertAdcChan_interrupt ********************************/

void BSP_ADC0_convertAdcChan_interrupt(CPU_INT16U adcChan)
{
	/* For SW trigger mode, SC1[0] is used */
	ADC0->SC1[0] &= ~ADC_SC1_ADCH_MASK;		 	 	// Clear prior ADCH bits
	
	ADC0->SC1[0] = ADC_SC1_ADCH(adcChan) | 0x40; 	// Initiate Conversion and AIEN=1
}

/************************************ ADC0_IRQHandler ************************************/

static void ADC0_IRQHandler(void)
{
	CPU_INT16U adc_result = 0;	// Storing ADC results
	OS_ERR os_err;

	OSIntEnter();				

	/* For SW trigger mode, R[0] is used */
	adc_result = ADC0->R[0];		
	/* ADC reading is mapped from 0-0xFFF range onto 8000-0 range and saved in adc_result*/

	ADC0_conv = (CPU_INT16U)(8000 - (8000 * adc_result) / 0xFFF); 	
																    

	ADC0->SC1[0] = 0x00007F; 	/* Disable conversion & clear interrupt */

	/* Post semaphore of ADC conversion to remove the according task from pending list */
	OSSemPost(&ADC0sem, OS_OPT_POST_1 | OS_OPT_POST_NO_SCHED, &os_err);
	OSIntExit();				// Exiting the interrupt
}

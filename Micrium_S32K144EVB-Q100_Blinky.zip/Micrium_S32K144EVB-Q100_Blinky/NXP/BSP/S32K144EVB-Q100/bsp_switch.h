/********************************************************************************************************
*
*
*										Filename:  bsp__switch.h
*									    Project:   OSES_Final_assignment
*										A.Y:       2019-2020
*
*										Student:   Stefania Gabutto, 265481
*											       Mohammadreza Beygifard, 257645
*
********************************************************************************************************/

#ifndef BSP_SWITCH_PRESENT
#define BSP_SWITCH_PRESENT

#ifdef __cplusplus
extern "C" {
#endif

	/*************************************************** Function Prototypes ****************************/

	void BSP_Switch_Init(void);

#ifdef __cplusplus
}
#endif

#endif
